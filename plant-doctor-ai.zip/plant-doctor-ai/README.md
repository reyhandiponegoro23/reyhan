# Plant Doctor AI

Asisten pertanian berbasis kamera HP dan AI vision untuk pengguna Indonesia. Aplikasi menyediakan pemeriksaan visual, hasil dengan keterbatasan yang jelas, serta riwayat lokal menggunakan IndexedDB.

## Menjalankan secara lokal

Prasyarat: Node.js 20+ dan npm.

```bash
npm install
cp .env.example .env
npm run dev
```

Frontend tersedia di http://localhost:5173 dan API di http://localhost:8787. Pada Windows PowerShell, salin konfigurasi dengan `Copy-Item .env.example .env`.

## Mengaktifkan analisis AI

Tambahkan `OPENAI_API_KEY` pada file `.env` untuk backend. Jangan memakai awalan `VITE_` pada key. Opsional, set `OPENAI_MODEL` ke model vision yang tersedia pada akun API (default `gpt-4o-mini`). Restart server setelah mengubah konfigurasi.

Foto baru dikirim setelah persetujuan pengguna. Server tidak menyimpan foto atau mencatat isi foto maupun API key. Tanpa API key, endpoint menampilkan pesan bahwa AI belum dikonfigurasi.

## Kamera HP

Akses kamera memerlukan HTTPS atau localhost. Untuk uji dari HP di jaringan, gunakan HTTPS tunnel/reverse proxy yang dipercaya dan arahkan permintaan `/api` ke backend. Pengguna bisa memilih foto dari galeri jika kamera tidak tersedia.

## Pemeriksaan proyek

```bash
npm run typecheck
npm run lint
npm test
npm run build
```

## Privasi dan batasan

Tidak diperlukan akun atau basis data cloud. Hasil serta thumbnail yang disimpan pengguna berada di IndexedDB browser dan dapat hilang saat data browser dihapus atau perangkat berganti. Analisis foto hanya memberi perkiraan, bukan diagnosis pasti. Foto saja tidak membuktikan tanaman bebas penyakit atau hasil panen aman dikonsumsi. Jangan menentukan dosis pestisida dari analisis ini.
