import { response } from './types';
const outputSchema = {
 type: 'object', additionalProperties: false,
 properties: {
  plantName: { type: ['string','null'] },
  inspectionType: { type: 'string', enum: ['doctor','pest','rice','harvest','weed','sorting','leaf','history'] },
  imageQuality: { type: 'string', enum: ['clear','insufficient','unusable'] },
  visibleSymptoms: { type: 'array', items: { type: 'string' } },
  primarySuspicion: { type: 'object', additionalProperties: false, properties: { name: { type: 'string' }, explanation: { type: 'string' }, confidence: { type: 'string', enum: ['low','medium','high'] } }, required: ['name','explanation','confidence'] },
  possibleCauses: { type: 'array', items: { type: 'object', additionalProperties: false, properties: { name: { type: 'string' }, reason: { type: 'string' } }, required: ['name','reason'] } },
  recommendedActions: { type: 'array', items: { type: 'string' } },
  precautions: { type: 'array', items: { type: 'string' } },
  expertHelpNeeded: { type: 'boolean' }, limitations: { type: 'array', items: { type: 'string' } }
 },
 required: ['plantName','inspectionType','imageQuality','visibleSymptoms','primarySuspicion','possibleCauses','recommendedActions','precautions','expertHelpNeeded','limitations']
};
export async function runVision(image: string, mime: string, kind: string) {
 const key = process.env.OPENAI_API_KEY;
 if (!key) throw Object.assign(new Error('NOT_CONFIGURED'), { status: 503 });
 const controller = new AbortController(); const timer = setTimeout(() => controller.abort(), 45000);
 try {
  const res = await fetch('https://api.openai.com/v1/responses', { method: 'POST', signal: controller.signal, headers: { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' }, body: JSON.stringify({ model: process.env.OPENAI_MODEL || 'gpt-4o-mini', store: false, max_output_tokens: 1200, input: [{ role: 'user', content: [{ type: 'input_text', text: 'Analisis foto untuk pemeriksaan ' + kind + '. Balas Bahasa Indonesia dengan JSON terstruktur. Pisahkan gejala tampak dari dugaan. Jangan diagnosis pasti atau beri dosis pestisida. Jika buram, tandai insufficient/unusable dan sarankan foto ulang. Berikan kemungkinan alternatif bila penyebab serupa. Jangan menyimpulkan tanaman bebas penyakit atau panen aman. inspectionType harus ' + kind + '.' }, { type: 'input_image', image_url: 'data:' + mime + ';base64,' + image, detail: 'high' }] }], text: { format: { type: 'json_schema', name: 'plant_diagnosis', strict: true, schema: outputSchema } } }) });
  if (!res.ok) throw Object.assign(new Error('PROVIDER'), { status: res.status });
  const body: any = await res.json(); const text = body.output?.flatMap((x: any) => x.content || []).find((x: any) => x.type === 'output_text')?.text;
  if (!text) throw new Error('INVALID');
  const parsed = response.safeParse(JSON.parse(text));
  if (!parsed.success || parsed.data.inspectionType !== kind) throw new Error('INVALID');
  return parsed.data;
 } finally { clearTimeout(timer); }
}
